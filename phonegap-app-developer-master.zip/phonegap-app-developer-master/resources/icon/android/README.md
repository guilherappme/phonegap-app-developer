# Generated Icons

## Service

https://undev.de/icon

## Source

    res/icon/icon-512.png

## Settings

- Mask: Round 2
- Overlay: None
- Shadow: 0%
